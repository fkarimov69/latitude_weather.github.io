-- Check to make sure the next set of installation steps are only run on 9.12 (or later) databases...
spool vercheck.log
set termout off;
set serverout on;
whenever SQLERROR exit failure;

DECLARE
   vSrvPkVersionMin  ml.symbol.value%TYPE := '9.12';
   vCurrVersion      ml.symbol.value%TYPE;

   ver_str varchar2(12);
   pos number;
   major number;

BEGIN
    vCurrVersion := logician_dbver();
	
    ver_str := vCurrVersion;
    pos := to_number(instr(ver_str, '.'));
    major := to_number(substr(ver_str, 1, pos-1));

--  Raise an error if database is not at the minimum service pack level (namely, if this is a pre-9.12 DB)
    IF vCurrVersion < vSrvPkVersionMin THEN
     if major < 9.12 THEN
        raise_application_error(-20002,'Not making 9.x updates to database version ' || vCurrVersion);
     END IF; 
    END IF;
    dbms_output.put_line('Loading 9.x updates...');
END;
/
exit
