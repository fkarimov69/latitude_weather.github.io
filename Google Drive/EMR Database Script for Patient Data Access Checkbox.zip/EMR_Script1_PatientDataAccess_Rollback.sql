spool EMR_PatientDataAccess_Script1_Rollback.log

DELETE FROM ml.Patches WHERE PatchName = 'EMR Database Script1 for Patient Data Access Checkbox';
COMMIT;

spool off

exit;