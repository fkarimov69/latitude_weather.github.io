spool EMR_PatientDataAccess_Script2_Rollback.log

DELETE FROM ml.Patches WHERE PatchName = 'EMR Database Script2 for Patient Data Access Checkbox';
COMMIT;

spool off

exit;